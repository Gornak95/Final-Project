import tkinter as tk
from tkinter import messagebox

# Global order list
order = []

# Function to navigate to a category window
def open_category(category):
    def add_item(item, price):
        order.append((item, price))
        messagebox.showinfo("Item Added", f"{item} has been added to your order.")

    category_window = tk.Toplevel()
    category_window.title(f"{category} Menu")

    items = {
        "Appetizers": ["Spring Rolls", 5.99, "Garlic Bread", 4.99],
        "Mains": ["Grilled Chicken", 12.99, "Veggie Pasta", 10.99],
        "Desserts": ["Cheesecake", 6.99, "Ice Cream", 4.99]
    }

    for i in range(0, len(items[category]), 2):
        item = items[category][i]
        price = items[category][i + 1]
        tk.Label(category_window, text=f"{item} - ${price}").pack()
        tk.Button(category_window, text="Add", command=lambda i=item, p=price: add_item(i, p)).pack()

    tk.Button(category_window, text="Back", command=category_window.destroy).pack()

# Function to display the order summary
def show_order_summary():
    summary_window = tk.Toplevel()
    summary_window.title("Order Summary")

    total = 0
    for item, price in order:
        tk.Label(summary_window, text=f"{item}: ${price}").pack()
        total += price

    tk.Label(summary_window, text=f"Total: ${total:.2f}").pack()

    tk.Button(summary_window, text="Checkout", command=checkout).pack()
    tk.Button(summary_window, text="Back", command=summary_window.destroy).pack()

# Function to handle checkout
def checkout():
    if not order:
        messagebox.showerror("Error", "Your order is empty! Please add items.")
        return

    messagebox.showinfo("Order Complete", "Thank you for your order!")
    order.clear()

# Main window setup
root = tk.Tk()
root.title("SmartMenu Ordering System")

# Main menu layout
tk.Label(root, text="Welcome to SmartMenu", font=("Arial", 18)).pack()
tk.Button(root, text="Appetizers", command=lambda: open_category("Appetizers")).pack()
tk.Button(root, text="Mains", command=lambda: open_category("Mains")).pack()
tk.Button(root, text="Desserts", command=lambda: open_category("Desserts")).pack()
tk.Button(root, text="Order Summary", command=show_order_summary).pack()
tk.Button(root, text="Exit", command=root.quit).pack()

root.mainloop()

